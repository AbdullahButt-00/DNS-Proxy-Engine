# simple_proxy.py - Enhanced version with dynamic IP specification

import threading, socket, logging, time, json, ipaddress, os, re
from datetime import datetime
from pathlib import Path
from dnslib.server import DNSServer, BaseResolver
from dnslib import DNSRecord, QTYPE, RR, A, DNSLabel
from dnslib import DNSRecord, QTYPE, RR, A
from scoring_engine import calculate_reputation
from threat_feed_manager import ThreatFeedManager
import requests

from config import load_thresholds

import copy    


# ── Config ───────────────────────────────────────────────

UPSTREAM        = ["8.8.8.8", "1.1.1.1"]

LISTEN_ADDR     = "0.0.0.0"

LISTEN_PORT     = 5300          # keep original port

MONITOR_MODE    = False

BLOCK_THR, SUSP_THR = load_thresholds()

BLOCK_PORTAL_IP = "10.0.1.27" #Global IP 


# ── Enhanced IP handling ──────────────────────────────────

# New feature: Allow IP specification in DNS queries
# Usage patterns supported:
# 1. dig @127.0.0.1 -p 5300 example.com (normal)
# 2. dig @127.0.0.1 -p 5300 example.com +client=192.168.1.100 (new feature)
# 3. Environment variable (legacy): export DNSPROXY_TEST_IP=192.10.10.200
# 4. Static override (legacy): FORCE_CLIENT_IP = "192.168.0.42"

FORCE_CLIENT_IP = os.getenv("DNSPROXY_TEST_IP") or " "   # Leave empty for dynamic behavior

# Enable dynamic IP extraction from DNS queries
# e.g test: dig @127.0.0.1 -p 5300 www.microsoft.com.client-192-168-1-201
ENABLE_DYNAMIC_IP = True

_ml_session     = requests.Session()

ML_API_URL      = "http://127.0.0.1:8500/score" # use Global Variable instead of 127.0.0.1

# ---------------------------------------------------------


# ── ML helper ────────────────────────────────────────────

def fetch_ml_score(domain: str) -> float:

    try:

        r = _ml_session.post(ML_API_URL, json={"domain": domain}, timeout=0.2)

        if r.status_code == 200:

            return round(r.json()["ml_badness"], 4)

    except Exception:

        pass  # API down → local model fallback


    from ml_scoring import compute_ml_score

    return compute_ml_score(domain)


# ── New IP extraction helper ──────────────────────────────

def extract_client_ip_from_query(request: DNSRecord, handler) -> str:
    """
    Extract client IP from DNS query using multiple methods:
    1. Check for +client=IP in query name (dig supports additional options)
    2. Check for special TXT records with IP info
    3. Parse additional records for custom IP specification
    4. Fall back to handler client address
    
    Returns the IP address to use for this query.
    """
    
    # Method 1: Extract from query name if it contains special syntax
    # Example: "example.com.client-192-168-1-100" -> 192.168.1.100
    qname = str(request.q.qname).rstrip(".").lower()
    
    # Check for client IP encoded in domain name
    client_pattern = r'\.client[-\.](\d+)[-\.](\d+)[-\.](\d+)[-\.](\d+)$'
    match = re.search(client_pattern, qname)
    if match:
        ip_parts = match.groups()
        client_ip = ".".join(ip_parts)
        try:
            # Validate IP format
            ipaddress.ip_address(client_ip)
            logging.getLogger("simple_proxy").info(f"🎯 Extracted client IP from query: {client_ip}")
            return client_ip
        except ipaddress.AddressValueError:
            pass
    
    # Method 2: Check additional records for custom client IP specification
    if hasattr(request, 'ar') and request.ar:
        for additional in request.ar:
            if additional.rtype == QTYPE.TXT:
                txt_data = str(additional.rdata)
                if txt_data.startswith('CLIENT_IP='):
                    client_ip = txt_data.split('=', 1)[1].strip('"')
                    try:
                        ipaddress.ip_address(client_ip)
                        logging.getLogger("simple_proxy").info(f"🎯 Extracted client IP from TXT record: {client_ip}")
                        return client_ip  
                    except ipaddress.AddressValueError:
                        pass
    
    # Method 3: Check query options (if DNS library supports it)
    # This would require parsing EDNS options, which is more complex
    
    # Fallback: Use the actual client address
    return handler.client_address[0]


# ─────────────────────────────────────────────────────────

class SimpleResolver(BaseResolver):

    # ------------- GUI-rule helper ------------------------

    def _match_gui_rule(self, client_ip: str, domain: str):

        try:

            with open("dns_rules.json", "r") as f:

                rules = json.load(f)

        except (FileNotFoundError, json.JSONDecodeError):

            return (None, None)


        domain = domain.lower().rstrip(".")

        for r in rules:

            if not r.get("enabled", True):

                continue

            if r.get("domain", "").lower().rstrip(".") in domain:

                act = r.get("action", "ALLOW").upper()

                if act == "REDIRECT":

                    return ("REDIRECT", r.get("redirect_to", "1.1.1.1"))

                return (act, None)

        return (None, None)


    def _match_static_rule(self, client_ip, domain):
        """
        Fixed version that properly handles both old and new rule formats
        """
        ip_obj = ipaddress.ip_address(client_ip)
        matching_rule_ip_override = None
        matching_rule_subnet = None
        
        for rule in self.static_rules:
            # Skip if domain doesn't match
            if rule["domain"].lower().rstrip(".") != domain.lower().rstrip("."):
                continue
                
            # Check for direct IP match with override (highest priority)
            if rule.get("ip_override") and rule.get("ip") == client_ip:
                matching_rule_ip_override = rule["ip_override"]
                
            # Check for subnet match (lower priority)
            if "subnet" in rule and rule.get("ip"):  # Make sure we have both subnet and ip
                try:
                    if ip_obj in ipaddress.ip_network(rule["subnet"]):
                        matching_rule_subnet = rule["ip"]
                except ValueError:
                    continue
        
        # Return the highest priority match
        result = matching_rule_ip_override or matching_rule_subnet
        
        if result:
            self.log.info(f"🎯 static rule matched for {domain} from {client_ip} → {result}")
        
        return result

    # new function to check if IP is in automatic blocklist

    def _is_ip_blacklisted(self, client_ip: str) -> bool:
        """Check if IP is in the automatic blacklist"""
        try:
            blacklist_file = "blacklist_ips.txt"
            if not os.path.exists(blacklist_file):
                return False
                
            with open(blacklist_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    # Handle both formats: "IP|timestamp" and just "IP"
                    if '|' in line:
                        blocked_ip = line.split('|')[0].strip()
                    else:
                        blocked_ip = line.strip()
                    
                    if blocked_ip == client_ip:
                        return True
        except Exception as e:
            self.log.error(f"Error checking IP blacklist: {e}")
        return False



    # ------------- ctor -----------------------------------

    def __init__(self):

        self.log = logging.getLogger("simple_proxy")


        # 0) threat feeds

        self.feed_mgr = ThreatFeedManager()

        self.feed_mgr.load_cached()

        threading.Thread(target=self._refresh_feeds, daemon=True).start()


        # 1) allow/deny lists

        self.wh_d = self._load("whitelist_domains.txt")

        self.bl_d = self._load("blacklist_domains.txt")

        self.wh_i = self._load("whitelist_ips.txt")

        self.bl_i = self._load("blacklist_ips.txt")


        # 2) legacy static rules

        try:

            with open("domain_rules.json") as f:

                self.static_rules = json.load(f)["rules"]

        except Exception:

            self.static_rules = []


        self.log.info("🟢 Resolver ready with dynamic IP extraction enabled")


    def _refresh_feeds(self):

        try:

            self.feed_mgr.update_feeds_sync()

            self.log.info("🌐 Threat feeds refreshed")

        except Exception as e:

            self.log.error(f"feed refresh failed: {e}")


    def _load(self, fn):

        try:

            return {l.strip().lower() for l in open(fn)

                    if l.strip() and not l.startswith("#")}

        except FileNotFoundError:

            Path(fn).touch()

            return set()


    def _forward(self, data: bytes):

        for ip in UPSTREAM:

            try:

                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:

                    s.settimeout(2)

                    s.sendto(data, (ip, 53))

                    resp, _ = s.recvfrom(512)

                    return resp

            except Exception:

                continue

        return None


    def _blockportal_reply(self, request: DNSRecord):

        qname = str(request.q.qname).rstrip(".")

        reply = request.reply()

        reply.add_answer(RR(qname, QTYPE.A, rdata=A(BLOCK_PORTAL_IP), ttl=60))

        return reply


    # ------------- Enhanced main resolver --------------------------

    def resolve(self, request: DNSRecord, handler):

        real_client = handler.client_address[0]

        
        # Enhanced IP determination logic
        if ENABLE_DYNAMIC_IP:
            # Try to extract IP from the DNS query itself
            extracted_ip = extract_client_ip_from_query(request, handler)
            if extracted_ip != real_client:
                self.log.info(f"🔄 Using extracted client IP: {extracted_ip} (real: {real_client})")
            client_raw = extracted_ip
        elif FORCE_CLIENT_IP.strip():
            # Legacy: Use static override
            client_raw = FORCE_CLIENT_IP.strip()
            self.log.debug(f"🔒 Using static override IP: {client_raw}")
        else:
            # Default: Use real client
            client_raw = real_client

        
        client = str(ipaddress.ip_address(client_raw))

        # Clean the query name (remove any client IP encoding)
        # ----- Preserve original qname and make a cleaned copy -----
        orig_qname  = str(request.q.qname).rstrip(".").lower()
        clean_qname = re.sub(r'\.client[-\.]\d+[-\.]\d+[-\.]\d+[-\.]\d+$', '', orig_qname)
        qname       = clean_qname           # the one we’ll pass to scoring, lists, etc.


        if not qname or qname.endswith(".local"):

            raw = self._forward(request.pack())

            return DNSRecord.parse(raw) if raw else request.reply()


        # 1. Check automatic IP blacklist first (always enforced)
        if self._is_ip_blacklisted(client):
            self.log.warning(f"🚫 Auto-blacklisted IP {client} → {BLOCK_PORTAL_IP}")
            return self._blockportal_reply(request)

        # 2. Hard blacklist (enforced if not in monitor mode)
        if (client in self.bl_i or qname in self.bl_d) and not MONITOR_MODE:
            self.log.warning(f"🚫 hard-blacklist → {BLOCK_PORTAL_IP}")
            return self._blockportal_reply(request)

        # 3. GUI Rules (dns_rules.json)
        gui_act, gui_ip = self._match_gui_rule(client, qname)
        if gui_act == "BLOCK" and not MONITOR_MODE:
            self.log.warning(f"🚫 GUI rule block → {BLOCK_PORTAL_IP}")
            return self._blockportal_reply(request)

        if gui_act == "REDIRECT":
            self.log.info(f"🎯 GUI redirect {orig_qname} → {gui_ip}")
            reply = request.reply()
            reply.add_answer(RR(orig_qname + '.', QTYPE.A, rdata=A(gui_ip), ttl=60))
            return reply

        # 4. Static Rule Match (we defer return until after verdict)
        static_ip = self._match_static_rule(client, qname)
        if static_ip:
            self.log.info(f"🎯 static rule matched for {qname} from {client} → {static_ip}")
            # NOTE: we do NOT return yet – we compute score first

        # 5. Whitelist (note: static overrides only skipped if whitelisted)
        # if client in self.wh_i or qname in self.wh_d:
        #     raw = self._forward(request.pack())
        #     return DNSRecord.parse(raw) if raw else request.reply()
        if client in self.wh_i or qname in self.wh_d:
            self.log.info(f"✅ Whitelist hit → ALLOW: {qname} from {client}")

            try:
                log_file = "dns_logs.json"
                entry = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "domain": qname,
                    "client_ip": client,
                    "verdict": "ALLOW",
                    "score": None,
                    "domain_age": None,
                    "network_score": None,
                    "ml_badness": None,
                    "traditional_scores": {
                        "domain_age": None,
                        "tld": None,
                        "frequency": None,
                        "entropy": None,
                        "threat": None,
                        "reverse": None,
                        "network": None
                    }
                }

                logs = []
                if os.path.exists(log_file) and os.path.getsize(log_file) > 0:
                    with open(log_file, "r") as f:
                        try:
                            logs = json.load(f)
                        except json.JSONDecodeError:
                            pass

                # Fix malformed entries
                fixed_logs = []
                for log in logs:
                    fixed_log = {
                        "timestamp": log.get("timestamp"),
                        "domain": log.get("domain"),
                        "client_ip": log.get("client_ip"),
                        "verdict": log.get("verdict"),
                        "score": log.get("score"),
                        "domain_age": log.get("domain_age"),
                        "network_score": log.get("network_score"),
                        "ml_badness": log.get("ml_badness"),
                        "traditional_scores": log.get("traditional_scores")
                    }

                    if fixed_log["traditional_scores"] is None:
                        fixed_log["traditional_scores"] = {
                            "domain_age": None,
                            "tld": None,
                            "frequency": None,
                            "entropy": None,
                            "threat": None,
                            "reverse": None,
                            "network": None
                        }

                    fixed_logs.append(fixed_log)

                # Check for duplicate
                if not any(
                    log["domain"] == qname and
                    log["client_ip"] == client and
                    log["timestamp"][:16] == entry["timestamp"][:16]
                    for log in fixed_logs
                ):
                    fixed_logs.append(entry)

                with open(log_file, "w") as f:
                    json.dump(fixed_logs, f, indent=2)

            except Exception as e:
                self.log.error(f"❌ Failed to save whitelist log: {e}")

            raw = self._forward(request.pack())
            return DNSRecord.parse(raw) if raw else request.reply()


        # 5. Reputation + ML Scoring

        trad_score, _unused, details = calculate_reputation(

            qname, client, BLOCK_THR, SUSP_THR

        )

        ml_badness   = fetch_ml_score(qname)

        ml_benignish = 1.0 - ml_badness


        if MONITOR_MODE and qname in self.bl_d:

            trad_w, ml_w = 0.30, 0.60

            self.log.debug(f"MONITOR+BL domain → weights trad={trad_w:.2f}, ML={ml_w:.2f}")

        else:

            trad_w, ml_w = 0.70, 0.20


        blend = trad_w * trad_score + ml_w * ml_benignish

        verdict = ("BLOCK" if blend < BLOCK_THR else

                "SUSPICIOUS" if blend < SUSP_THR else

                "ALLOW")


        # 6. Logging

        age_score     = details.get("domain_age", 0.0)

        network_score = details.get("network", 0.0)

        self.log.info(f"📅 DomainAge={age_score:.2f} 🌐Net={network_score:.2f} "

                    f"🤖ML={ml_badness:.2f} → {verdict} ({blend:.2f})")

        self.log.info(

            f"DNS Query | timestamp={datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')} | "

            f"client={client} | domain={qname} | score={blend:.2f} | verdict={verdict}"

        )


        # 7. JSON Log

        try:

            log_file = "dns_logs.json"

            entry = {

                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),

                "domain": qname,

                "client_ip": client,

                "verdict": verdict,

                "score": round(blend, 2),

                "domain_age": round(age_score, 2),

                "network_score": round(network_score, 2),

                "ml_badness": round(ml_badness, 2),

                "traditional_scores": {k: round(v, 2) for k, v in details.items()},

            }

            logs = []

            if os.path.exists(log_file) and os.path.getsize(log_file) > 0:

                with open(log_file, "r") as f:

                    try:

                        logs = json.load(f)

                    except json.JSONDecodeError:

                        pass

            if not any(

                l["domain"] == qname and l["client_ip"] == client

                and l["timestamp"][:16] == entry["timestamp"][:16]

                for l in logs

            ):

                logs.append(entry)

                with open(log_file, "w") as f:

                    json.dump(logs, f, indent=2)

        except Exception as e:

            self.log.error(f"❌ Failed to save log: {e}")


        # 8. BLOCK if verdict requires it

        if verdict == "BLOCK" and not MONITOR_MODE:

            self.log.warning(f"🚫 reputation block → {BLOCK_PORTAL_IP}")

            return self._blockportal_reply(request)


        # 9. Apply static IP override, if matched earlier

        if static_ip:

            self.log.info(f"✅ applying static IP override → {static_ip}")

            reply = request.reply()
            reply.add_answer(RR(orig_qname + '.', QTYPE.A, rdata=A(static_ip), ttl=60))
            return reply

        # 10. Normal case → forward upstream ---------------------------------
        fwd_req = copy.deepcopy(request)          # keep ID/flags intact
        fwd_req.q.qname = DNSLabel(clean_qname + '.')   # upstream sees clean name
        raw = self._forward(fwd_req.pack())

        if raw:
            resp = DNSRecord.parse(raw)
            # restore the ORIGINAL qname so it matches the stub’s question
            resp.q.qname = DNSLabel(orig_qname + '.')
            return resp
        return request.reply()



# ── CLI runner ───────────────────────────────────────────

if __name__ == "__main__":

    logging.basicConfig(level=logging.INFO,

                        format="%(asctime)s %(levelname)s %(message)s")

    srv = DNSServer(SimpleResolver(), address=LISTEN_ADDR,

                    port=LISTEN_PORT, tcp=False, logger=None)

    srv.start_thread()

    logging.getLogger().info(

        f"DNS proxy listening on {LISTEN_ADDR}:{LISTEN_PORT} with dynamic IP extraction"

    )

    try:

        while True:

            time.sleep(1)

    except KeyboardInterrupt:

        pass