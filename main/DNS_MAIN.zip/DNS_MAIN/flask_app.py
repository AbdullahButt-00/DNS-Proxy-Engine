# flask_app.py
# ===========================================================================
# 0) Ensure the HF malicious-URL model is cached (exactly as in Script 1)
# ===========================================================================
print("🔽 Checking ML model cache…")
try:
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    MODEL = "kmack/malicious-url-detection"
    AutoTokenizer.from_pretrained(MODEL)
    AutoModelForSequenceClassification.from_pretrained(MODEL)
    print("✅ ML model is cached and ready.")
except Exception as e:
    print(f"❌ Failed to cache ML model: {e}")
    # If you need this to be fatal in prod, uncomment:
    # import sys; sys.exit(1)

# ===========================================================================
# 1) Imports
# ===========================================================================
import threading, logging, re, json, os, time
from collections import deque
from datetime import datetime, timedelta
from pathlib import Path
import traceback
from flask import jsonify, request
from functools import wraps
from flask import Flask, render_template, jsonify, request, session
from dnslib.server import DNSServer
import uvicorn

import simple_proxy as sp          # DNS proxy + scoring logic
import ml_api                      # FastAPI micro-service (loaded here so uvicorn can re-use it)
import threat_feed_manager as tfm          # ← NEW: to toggle NRD flag

from config import save_thresholds

from werkzeug.security import generate_password_hash, check_password_hash

# Import the IP monitoring system
from ip_blacklist_monitor import ip_monitor

# -- NRD persistence --------------------------------------------------------
NRD_STATE_FILE = "nrd_state.json"

def _load_nrd_state() -> bool:
    try:
        with open(NRD_STATE_FILE) as f:
            return bool(json.load(f).get("enabled", False))
    except (FileNotFoundError, json.JSONDecodeError):
        return False

def _save_nrd_state(enabled: bool) -> None:
    with open(NRD_STATE_FILE, "w") as f:
        json.dump({"enabled": enabled}, f)

# Initialise NRD flag from disk, then propagate to ThreatFeedManager
initial_nrd = _load_nrd_state()
tfm.set_nrd_enabled(initial_nrd)

logging.basicConfig(
    level=logging.DEBUG,                     # show DEBUG and above
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)

print(">> ml_api loaded from", ml_api.__file__)
print(">> ml_api has attributes", dir(ml_api))

# ===========================================================================
# 2) Flask app  &  in-memory logging  (keeps Script-1 behaviour)
# ===========================================================================
app        = Flask(__name__)
app.secret_key = 'super_secret_key'  # Needed for session management
log_buffer = deque(maxlen=500)


# ── Chunking ─────────────────────────────────────────────
CHUNK_DIR = Path("chunk_store")
CHUNK_DIR.mkdir(exist_ok=True)

class InMemoryHandler(logging.Handler):
    """
    Script-1 pushed every log line; Script-2 wanted to filter for DNS lines.
    We keep **both**: everything is still stored, but DNS lines are easy to
    detect later for analytics.
    """
    def emit(self, record):
        log_entry = self.format(record)
        log_buffer.append(log_entry)

proxy_logger = logging.getLogger("simple_proxy")
proxy_logger.setLevel(logging.INFO)
mem_handler   = InMemoryHandler()
mem_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
proxy_logger.addHandler(mem_handler)

# ===========================================================================
# 3) Make sure JSON persistence files exist (new in Script-2)
# ===========================================================================
DATA_FILES = ['dns_logs.json', 'dns_rules.json', 'users.json']
BLACKLIST_IPS_FILE = "blacklist_ips.txt"

for file in DATA_FILES:
    Path(file).touch(exist_ok=True)

# ===========================================================================
# 4) Helper load / save functions (from Script-2 additions)
# ===========================================================================
def _safe_json_load(path, default):
    try:
        with open(path, 'r') as f:
            data = json.load(f)
            return data if isinstance(data, list) else default
    except (FileNotFoundError, json.JSONDecodeError):
        return default
    
# --- password auto-upgrade ---------------------------------

HASH_PREFIXES = ("pbkdf2:", "scrypt:", "argon2:", "sha256:")

def _ensure_hashed(user: dict) -> dict:
    """
    Hash clear-text passwords exactly once.
    Does *nothing* if the field already looks like a Werkzeug hash.
    """
    raw = user.get("password", "")
    if not raw.startswith(HASH_PREFIXES):
        user["password"] = generate_password_hash(raw)      # uses current default (scrypt) 
    return user

def load_dns_logs():   return _safe_json_load('dns_logs.json', list(log_buffer))
def load_dns_rules():  return _safe_json_load('dns_rules.json', [])

def load_users():
    users = _safe_json_load('users.json', [])
    users = [_ensure_hashed(u) for u in users]

    if users:
        return users

    # only happens on a fresh install
    default = {
        "id"      : 1,
        "username": "admin",
        "email"   : "admin@dns-shield.com",
        "role"    : "Administrator",
        "status"  : "Active",
        "password": "admin123"
    }
    return [_ensure_hashed(default)]           # <— hash it here


def save_dns_rules(r):  Path('dns_rules.json').write_text(json.dumps(r, indent=2))
def save_users(u):      Path('users.json').write_text(json.dumps(u, indent=2))




# Role-checking decorator (simplified)
def requires_role(role):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not user_has_role(current_user, role):  # Replace with your auth logic
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return wrapped
    return decorator


# ---------------------------------------------------------------------------
# domain_rules.json helpers  – structure is {"rules": [ … ] }
# ---------------------------------------------------------------------------
DOMAIN_RULES_FILE = "domain_rules.json"
Path(DOMAIN_RULES_FILE).touch(exist_ok=True)          # make sure the file exists

def load_domain_rules() -> dict:
    try:
        with open(DOMAIN_RULES_FILE, "r") as f:
            data = json.load(f)
            # guarantee correct skeleton even if file is empty or mangled
            if isinstance(data, dict) and "rules" in data and isinstance(data["rules"], list):
                return data
    except (json.JSONDecodeError, FileNotFoundError):
        pass
    return {"rules": []}

def save_domain_rules(data: dict) -> None:
    # **never overwrite** the whole file blindly: we only write the validated dict
    Path(DOMAIN_RULES_FILE).write_text(json.dumps(data, indent=2))


# ===========================================================================
# 5) Background threads (ML-API & DNS proxy)
#     – ML server wrapped in try/except (Script-2)
# ===========================================================================
def run_ml_api():
    try:
        uvicorn.run(
            app       = ml_api.app,
            host      = "127.0.0.1",
            port      = 8500,
            log_level = "info",
            access_log= False,
        )
    except OSError as e:
        if "address already in use" in str(e).lower():
            proxy_logger.warning("🛰️ ML API already running on port 8500")
        else:
            proxy_logger.error(f"❌ ML API server error: {e}")

threading.Thread(target=run_ml_api, daemon=True).start()
proxy_logger.info("🛰️ ML API server starting on http://127.0.0.1:8500")

def run_dns_proxy():
    resolver = sp.SimpleResolver()
    server   = DNSServer(resolver,
                         address = sp.LISTEN_ADDR,
                         port    = sp.LISTEN_PORT,
                         tcp     = False,
                         logger  = None)  # dnslib default logger
    server.start_thread()
    proxy_logger.info(f"✅ DNS Proxy listening on {sp.LISTEN_ADDR}:{sp.LISTEN_PORT}")

threading.Thread(target=run_dns_proxy, daemon=True).start()

# New feature -> ensures that the user entered value for the size of file for the new chunk gets saved
CHUNK_CFG_FILE = "chunk_config.json"
Path(CHUNK_CFG_FILE).touch(exist_ok=True)

def _load_chunk_cfg() -> float:
    try:
        with open(CHUNK_CFG_FILE) as f:
            return float(json.load(f).get("chunk_size_mb", 0))
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return 0.0

def _save_chunk_cfg(size_mb: float) -> None:
    with open(CHUNK_CFG_FILE, "w") as f:
        json.dump({"chunk_size_mb": size_mb}, f)

# --------------------------------------------------------
def _build_chunk(size_mb: float) -> None:
    """
    Collect newest log entries until ≤ size_mb and write a JSON file inside ./chunk_store.
    Preserves all original log data while creating properly formatted chunks.
    """
    try:
        # 1. Load logs from all available sources
        sources = []
        
        # From memory buffer (newest logs)
        buffer_logs = list(log_buffer)
        if buffer_logs:
            sources.append(('buffer', buffer_logs))
        
        # From dns_logs.json file (older logs)
        try:
            with open("dns_logs.json") as f:
                file_logs = json.load(f)
                if file_logs:
                    sources.append(('file', file_logs))
        except (FileNotFoundError, json.JSONDecodeError):
            pass
        
        # From existing chunks (if we want to include them)
        # chunk_files = sorted(CHUNK_DIR.glob("*.json"), key=lambda f: f.stat().st_mtime)
        # for chunk_file in chunk_files[-3:]:  # Only last 3 chunks to avoid duplication
        #     try:
        #         with open(chunk_file) as f:
        #             chunk_logs = json.load(f)
        #             if chunk_logs:
        #                 sources.append((f'chunk:{chunk_file.name}', chunk_logs))
        #     except:
        #         continue

        # 2. Normalize all log entries to consistent format
        normalized_logs = []
        
        for source_name, logs in sources:
            for log in logs:
                entry = {}
                
                # Handle both string and dict formats
                if isinstance(log, str):
                    # Parse string format (key=value pairs)
                    for part in log.split(' | '):
                        if '=' in part:
                            key, val = part.split('=', 1)
                            entry[key.strip()] = val.strip()
                elif isinstance(log, dict):
                    entry = log.copy()
                
                # Ensure required fields exist with defaults
                entry.setdefault('timestamp', datetime.now().isoformat())
                entry.setdefault('domain', 'unknown')
                entry.setdefault('client_ip', entry.get('client', '127.0.0.1'))
                entry.setdefault('verdict', 'ALLOW')
                entry.setdefault('score', 0.0)
                
                # Ensure numeric fields are properly typed
                numeric_fields = ['score', 'domain_age', 'tld', 'frequency', 
                                'entropy', 'threat', 'reverse', 'network', 'ml_badness']
                for field in numeric_fields:
                    if field in entry:
                        try:
                            entry[field] = float(entry[field])
                        except (ValueError, TypeError):
                            entry[field] = 0.0
                
                # Ensure traditional_scores exists and is properly formatted
                if 'traditional_scores' not in entry:
                    entry['traditional_scores'] = {
                        'domain_age': entry.get('domain_age', 0),
                        'tld': entry.get('tld', 0),
                        'frequency': entry.get('frequency', 0),
                        'entropy': entry.get('entropy', 0),
                        'threat': entry.get('threat', 0),
                        'reverse': entry.get('reverse', 0),
                        'network': entry.get('network', 0)
                    }
                
                normalized_logs.append(entry)

         # Remove entries with domain set as 'unknown'
        normalized_logs = [entry for entry in normalized_logs if entry.get("domain") != "unknown"]
        # 3. Sort all logs by timestamp (newest first)
        normalized_logs.sort(
            key=lambda x: datetime.fromisoformat(x['timestamp'].replace('Z', '+00:00')),
            reverse=True
        )

        # 4. Create bundle within size limit
        limit_bytes = int(size_mb * 1024 * 1024)
        bundle = []
        total_bytes = 0

        for entry in normalized_logs:
            entry_bytes = len(json.dumps(entry, separators=(",", ":")).encode())
            
            # Only add if we have space or it's the first entry
            if total_bytes + entry_bytes > limit_bytes and bundle:
                break
                
            bundle.append(entry)
            total_bytes += entry_bytes

        # 5. Save to chunk file (oldest first in file)
        if bundle:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            chunk_name = CHUNK_DIR / f"{ts}_{size_mb:.2f}MB.json"
            
            # Ensure chronological order in file (oldest first)
            bundle_sorted = sorted(
                bundle,
                key=lambda x: datetime.fromisoformat(x['timestamp'].replace('Z', '+00:00'))
            )
            
            with open(chunk_name, 'w') as f:
                json.dump(bundle_sorted, f, indent=2)
            
            proxy_logger.info(
                f"🗂️ Chunk created: {chunk_name} "
                f"({len(bundle)} entries, {total_bytes/1024:.1f} KB)"
            )
        else:
            proxy_logger.warning("No logs available to create chunk")

    except Exception as e:
        proxy_logger.error(f"❌ Chunk creation failed: {str(e)}")
        proxy_logger.error(traceback.format_exc())

# def _build_chunk(size_mb: float) -> None:
#     """
#     Collect newest log entries until ≤ size_mb and write a
#     JSON file inside ./chunk_store.  Runs in a daemon thread.
#     """
#     try:
#         # Load logs from both sources
#         buffer_logs = list(log_buffer)
#         try:
#             with open("dns_logs.json") as f:
#                 file_logs = json.load(f)
#         except (FileNotFoundError, json.JSONDecodeError):
#             file_logs = []
        
#         # Combine and normalize logs
#         all_logs = []
        
#         # Process buffer logs (usually strings)
#         for log in buffer_logs:
#             if isinstance(log, str):
#                 # Parse string log into dict format
#                 parsed = {}
#                 for part in log.split(' | '):
#                     if '=' in part:
#                         k, v = part.split('=', 1)
#                         parsed[k.strip()] = v.strip()
                
#                 # Add timestamp if not present
#                 if 'timestamp' not in parsed:
#                     parsed['timestamp'] = datetime.now().isoformat()
                
#                 all_logs.append(parsed)
#             else:
#                 all_logs.append(log)
        
#         # Process file logs (should be dicts)
#         for log in file_logs:
#             if isinstance(log, dict):
#                 all_logs.append(log)
#             else:
#                 # Handle string logs from file
#                 parsed = {}
#                 for part in str(log).split(' | '):
#                     if '=' in part:
#                         k, v = part.split('=', 1)
#                         parsed[k.strip()] = v.strip()
                
#                 if 'timestamp' not in parsed:
#                     parsed['timestamp'] = datetime.now().isoformat()
                
#                 all_logs.append(parsed)

#         # Sort newest→oldest by timestamp (safer than "bottom of file")
#         def _ts(e):
#             try:
#                 ts = e.get("timestamp", "")
#                 if ts:
#                     return datetime.fromisoformat(ts.replace('Z', '+00:00'))
#                 return datetime.min
#             except Exception:
#                 return datetime.min
        
#         all_logs = sorted(all_logs, key=_ts, reverse=True)

#         limit_bytes = int(size_mb * 1024 * 1024)
#         bundle      = []
#         total       = 0

#         for entry in all_logs:
#             entry_bytes = len(json.dumps(entry, separators=(",", ":")).encode())
#             if total + entry_bytes > limit_bytes and bundle:
#                 # Next entry would overflow and we have at least one entry → stop
#                 break
#             bundle.append(entry)
#             total += entry_bytes

#         # Keep chronological order inside the chunk (oldest→newest)
#         bundle = bundle[::-1]

#         ts   = datetime.now().strftime("%Y%m%d%H%M%S")
#         base = f"{ts}_{size_mb:.2f}MB"
#         idx  = 1
#         fname = CHUNK_DIR / f"{base}_{idx}.json"
#         while fname.exists():          # never overwrite
#             idx += 1
#             fname = CHUNK_DIR / f"{base}_{idx}.json"

#         with open(fname, "w") as f:
#             json.dump(bundle, f, indent=2)

#         proxy_logger.info(f"🗂️  New chunk written → {fname} ({total/1024:.1f} KB, {len(bundle)} entries)")
        
#         # Debug: Log a sample entry from the chunk
#         if bundle:
#             proxy_logger.info(f"Sample chunk entry: {bundle[0]}")

#     except Exception as e:
#         proxy_logger.error(f"❌ Chunk building error: {e}")
#         import traceback
#         proxy_logger.error(traceback.format_exc())


# ===========================================================================
# 6) ROUTES – originals + new admin/analytics APIs
# ===========================================================================
app.secret_key = 'super_secret_key' 
@app.route("/")
def index():
    return render_template("index.html")

# Updated login API endpoint
@app.route("/login", methods=["POST"])
def login_api():
    username = request.json.get('username')
    password = request.json.get('password')

    users = load_users()                       # already auto-hashed
    user  = next((u for u in users if u["username"] == username), None)

    if user and check_password_hash(user["password"], password):
        session['authenticated'] = True
        session['username'] = username
        session['role'] = user["role"]  # Store user role in session
        return jsonify({
            "success": True, 
            "username": username,
            "role": user["role"]
        })

    return jsonify({"success": False, "error": "Invalid credentials"}), 401

# Logout endpoint
@app.route("/logout", methods=["POST"])
def logout_api():
    session.pop('authenticated', None)
    session.pop('username', None)
    return jsonify({"success": True})

# Add this middleware to check authentication for all routes except login
@app.before_request
def check_authentication():
    # Allow login page, static files, and the login API endpoint
    if request.path == '/' or \
       request.path.startswith('/static') or \
       request.path == '/login' or \
       request.path == '/api/current-user':
        return
    
    # Check if user is authenticated
    if not session.get('authenticated'):
        return jsonify({"error": "Unauthorized"}), 401
    
    # Get current user's role
    user_role = session.get('role', 'Viewer')
    
    # Define restricted routes for non-admins
    restricted_routes = [
        '/api/dns-rules', '/api/dns-rules/', 
        '/user-management-page', 
        '/settings-page',
        '/api/users', '/api/users/',
        '/api/blacklist-ips', '/api/blacklist-ips/',
        '/api/ip-settings',
        '/update-thresholds',
        '/api/nrd-status',
        '/toggle_mode'
    ]
    
    # Check if the current route is restricted for non-admins
    if user_role != 'Administrator' and any(request.path.startswith(route) for route in restricted_routes):
        return jsonify({"error": "Forbidden - Administrator access required"}), 403
    





# ---------- User Role-------------------------------------------------------
@app.route("/api/current-user")
def current_user():
    if not session.get('authenticated'):
        return jsonify({"error": "Unauthorized"}), 401
    
    users = load_users()
    user = next((u for u in users if u["username"] == session['username']), None)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    return jsonify({
        "username": user["username"],
        "role": user["role"],
        "email": user.get("email", ""),
        "status": user.get("status", "Active")
    })
    

#---------------- Block Page-------------------------------------------------
@app.route("/blocked")
def blocked_page():
    domain = request.args.get('domain', 'unknown-domain')
    client_ip = request.args.get('client_ip', 'unknown')
    score = request.args.get('score', '0.00')
    return render_template("blocked.html", domain=domain, client_ip=client_ip, score=score)


# ---------- LOGS -----------------------------------------------------------
@app.route("/logs")
def logs():
    """
    • Combines in-memory buffer + on-disk logs unless buffer_only=true
    • Still returns a *list* so existing front-end won't break.
    """
    buffer_only = request.args.get('buffer_only', 'false').lower() == 'true'
    old_order = request.args.get('old_order', 'false').lower() == 'true'
    
    if buffer_only:
        buffer_logs = list(log_buffer)
    else:
        buffer_logs = list(log_buffer)
        file_logs = load_dns_logs()

    # Parse any plain-text records into dicts for consistency
    def _parse(line_or_dict):
        if isinstance(line_or_dict, str):
            out = {}
            for part in line_or_dict.split(' | '):
                if '=' in part:
                    k, v = part.split('=', 1)
                    out[k.strip()] = v.strip()
            # carry raw text too, in case UI expects it
            out['_raw'] = line_or_dict
            return out
        return line_or_dict

    merged = [_parse(x) for x in (buffer_logs + ([] if buffer_only else file_logs))]
    merged = merged[-500:]                # cap
    merged = merged if old_order else merged[::-1]  # newest first
    return jsonify(merged)

# NEW Feature: This is related to chunk logic and handles edge cases
@app.route("/api/chunk-size", methods=["GET", "POST"])
def chunk_size():
    """
    GET  →  {"chunk_size_mb": <float>}
    POST →  body = {"chunk_size_mb": <float>}
             • validates >0 and ≤ current dns_logs.json size
    """
    if request.method == "POST":
        try:
            new_size = float(request.json.get("chunk_size_mb", 0))
        except (TypeError, ValueError):
            return jsonify({"error": "Size must be a number"}), 400

        if new_size <= 0:
            return jsonify({"error": "Size must be > 0"}), 400

        log_bytes = os.path.getsize("dns_logs.json") if os.path.exists("dns_logs.json") else 0
        max_mb    = log_bytes / (1024 * 1024)

        if new_size > max_mb:
            return jsonify({"error": f"Size exceeds current log file ({max_mb:.2f} MB)"}), 400

        _save_chunk_cfg(new_size)

        # 🔹 kick off background chunk build
        threading.Thread(
            target=_build_chunk,
            args=(new_size,),
            daemon=True
        ).start()

        return jsonify({"success": True, "chunk_size_mb": new_size})
    

    # GET
    return jsonify({"chunk_size_mb": _load_chunk_cfg()})

# ---------- CHUNK FILTER ----------------------------------------------------


@app.route("/api/chunk-filter", methods=["POST"])
def chunk_filter():
    """
    Enhanced filtering that:
    - Checks both chunks and current logs
    - Handles partial matches
    - Maintains all existing functionality
    """
    try:
        payload = request.json or {}
        filters = payload.get("filters", {})
        
        # 1. Collect logs from all available sources
        all_logs = []
        
        # Check chunks first (newest first)
        chunk_files = sorted(
            CHUNK_DIR.glob("*.json"),
            key=lambda f: f.stat().st_mtime,
            reverse=True
        )
        
        for chunk_file in chunk_files[:3]:  # Only check last 3 chunks
            try:
                with open(chunk_file) as f:
                    all_logs.extend(json.load(f))
            except:
                continue
        
        # Fall back to current logs if no chunks or need more data
        if not all_logs or filters.get('include_current', False):
            try:
                with open("dns_logs.json") as f:
                    all_logs.extend(json.load(f))
            except:
                pass
            
            # Add in-memory buffer logs
            all_logs.extend(list(log_buffer))
        
        # 2. Normalize all log entries
        normalized = []
        for log in all_logs:
            entry = {}
            
            if isinstance(log, str):
                # Parse string format
                for part in log.split(' | '):
                    if '=' in part:
                        key, val = part.split('=', 1)
                        entry[key.strip()] = val.strip()
            elif isinstance(log, dict):
                entry = log
            
            # Ensure required fields
            entry.setdefault('client_ip', entry.get('client', ''))
            entry.setdefault('domain', '')
            entry.setdefault('verdict', '')
            entry.setdefault('timestamp', '')
            
            normalized.append(entry)
        
        # 3. Apply filters
        def matches(entry):
            # Domain filter (partial match)
            if filters.get("domain"):
                if filters["domain"].lower() not in entry['domain'].lower():
                    return False
            
            # Client IP filter (exact match)
            if filters.get("client_ip"):
                if entry['client_ip'] != filters["client_ip"]:
                    # Try IP normalization
                    normalized_ip = re.sub(r'(\.0+)(?=\d|$)', '.', entry['client_ip'])
                    if normalized_ip != filters["client_ip"]:
                        return False
            
            # Verdict filter
            if filters.get("verdict"):
                if entry['verdict'].upper() != filters["verdict"].upper():
                    return False
            
            # Date range filter
            if filters.get("date_range"):
                try:
                    log_date = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                    start = datetime.fromisoformat(filters["date_range"][0])
                    end = datetime.fromisoformat(filters["date_range"][1] + " 23:59:59")
                    if not (start <= log_date <= end):
                        return False
                except:
                    return False
            
            return True
        
        filtered = [e for e in normalized if matches(e)]
        
        # 4. Return results (newest first)
        filtered.sort(
            key=lambda x: datetime.fromisoformat(x['timestamp'].replace('Z', '+00:00')),
            reverse=True
        )
        
        return jsonify(filtered[:500])  # Limit to 500 most recent
    
    except Exception as e:
        proxy_logger.error(f"Filter error: {str(e)}")
        return jsonify({
            "error": "Filtering failed",
            "details": str(e)
        }), 500




#------------  FETCH DOMAIN DETAILS ---------------------------------
@app.route("/domain-details")
def domain_details():
    domain = request.args.get('domain')
    client_ip = request.args.get('client_ip', None)
    
    # Load logs directly from dns_logs.json file
    try:
        with open('dns_logs.json', 'r') as f:
            logs = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        logs = []
    
    # Find the most recent matching log entry
    matching_log = None
    for log in reversed(logs):
        # Handle both dict and string formats
        if isinstance(log, dict):
            log_domain = log.get('domain')
            # Fixed: use client_ip instead of client
            log_client = log.get('client_ip') or log.get('client')
        else:
            # Parse plain-text logs
            domain_match = re.search(r'domain=([^\s|]+)', log)
            client_match = re.search(r'client=([^\s|]+)', log)
            log_domain = domain_match.group(1) if domain_match else None
            log_client = client_match.group(1) if client_match else None
        
        if log_domain == domain and log_client == client_ip:
            matching_log = log
            break
    
    if not matching_log:
        return jsonify({"error": "Domain details not found"}), 404
    
    # Extract scores from log
    scores = {}
    if isinstance(matching_log, dict):
        # Extract basic info
        scores = {
            "domain": matching_log.get("domain"),
            "client_ip": matching_log.get("client_ip"),
            "verdict": matching_log.get("verdict"),
            "score": matching_log.get("score"),
            "domain_age": matching_log.get("domain_age", 0),
            "network": matching_log.get("network_score", 0),
            "ml_score": matching_log.get("ml_badness", 0),
        }
        
        # Extract traditional scores from nested dictionary
        trad_scores = matching_log.get("traditional_scores", {})
        for key in ["tld", "frequency", "entropy", "threat", "reverse"]:
            scores[key] = trad_scores.get(key, 0)
    else:
        # Parse plain-text log
        scores = {
            "domain": domain,
            "client_ip": client_ip,
            "verdict": re.search(r'verdict=(\w+)', matching_log).group(1) if re.search(r'verdict=(\w+)', matching_log) else "",
            "score": re.search(r'score=([\d.]+)', matching_log).group(1) if re.search(r'score=([\d.]+)', matching_log) else "",
        }
        # Extract additional scores if available
        for key in ["domain_age", "tld", "frequency", "entropy", "threat", "reverse", "network", "ml_score"]:
            match = re.search(fr'{key}=([\d.]+)', matching_log)
            scores[key] = match.group(1) if match else "0.0"
    
    return jsonify(scores)

# ---------- STATUS / MODE TOGGLE (unchanged) -------------------------------
@app.route("/status")
def status():
    return jsonify({
        "running"             : True,
        "mode"                : "MONITOR" if sp.MONITOR_MODE else "ACTIVE",
        "block_threshold"     : sp.BLOCK_THR,
        "suspicious_threshold": sp.SUSP_THR
    })

@app.route("/toggle_mode", methods=["POST"])
def toggle_mode():
    sp.MONITOR_MODE = not sp.MONITOR_MODE
    mode = "MONITOR" if sp.MONITOR_MODE else "ACTIVE"
    proxy_logger.warning(f"### Mode switched to {mode} ###")
    return jsonify({"mode": mode})


# ---------- NRD toggle (updated) -------------------------------------------
@app.route("/api/nrd-status", methods=["GET", "POST"])
def nrd_status():
    if request.method == "POST":
        enabled = bool(request.json.get("nrd_enabled", False))
        tfm.set_nrd_enabled(enabled)
        _save_nrd_state(enabled)          # ← NEW: remember it
        return jsonify({"nrd_enabled": enabled})

    return jsonify({"nrd_enabled": tfm.NRD_ENABLED})


#-------------------   Threshold Settings -----------------------------------
# Add this near the other routes in flask_app.py
@app.route("/update-thresholds", methods=["POST"])
def update_thresholds():
    data = request.json
    block_thr = float(data.get('block_threshold'))
    susp_thr = float(data.get('suspicious_threshold'))
    
    # Validate thresholds
    if not (0 <= block_thr < susp_thr <= 1):
        return jsonify({"error": "Block must be < Suspicious and both between 0-1"}), 400
    
    # Update thresholds
    sp.BLOCK_THR, sp.SUSP_THR = block_thr, susp_thr
    save_thresholds(block_thr, susp_thr)
    
    proxy_logger.info(f"Updated thresholds: BLOCK_THR={block_thr}, SUSP_THR={susp_thr}")
    return jsonify({"success": True, "block_threshold": block_thr, "suspicious_threshold": susp_thr})


#----------------- Blacklist IPs ------------------------------
@app.route('/api/blacklist-ips', methods=['GET'])
def get_blacklist_ips():
    ips = []
    try:
        if os.path.exists(BLACKLIST_IPS_FILE):
            with open(BLACKLIST_IPS_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split('|')
                        if len(parts) >= 2:
                            ips.append({
                                "ip": parts[0],
                                "timestamp": parts[1]
                            })
                        else:
                            ips.append({
                                "ip": line,
                                "timestamp": "Unknown"
                            })
    except Exception as e:
        proxy_logger.error(f"Error reading blacklist: {str(e)}")
        return jsonify({"error": "Failed to read blacklist"}), 500
    
    return jsonify(ips)

@app.route('/api/blacklist-ips/<ip>', methods=['DELETE'])
def unblock_ip(ip):
    try:
        # Read existing IPs
        ips = []
        if os.path.exists(BLACKLIST_IPS_FILE):
            with open(BLACKLIST_IPS_FILE, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith(ip):
                        ips.append(line)
        
        # Write back without the unblocked IP
        with open(BLACKLIST_IPS_FILE, 'w') as f:
            for ip_entry in ips:
                f.write(f"{ip_entry}\n")
        
        return jsonify({"success": True})
    except Exception as e:
        proxy_logger.error(f"Error unblocking IP: {str(e)}")
        return jsonify({"error": "Failed to unblock IP"}), 500

# CHANGE
@app.route('/api/ip-settings', methods=['GET', 'POST'])
def ip_settings():
    if request.method == 'POST':
        data = request.json
        time = data.get('time')
        threshold = data.get('threshold')
        
        # Validate inputs
        if not time or not threshold:
            return jsonify({"error": "Missing parameters"}), 400
        
        try:
            # Validate values
            time_int = int(time)
            threshold_int = int(threshold)
            
            if time_int <= 0 or threshold_int <= 0:
                return jsonify({"error": "Values must be positive integers"}), 400
            
            # Save to ip_settings.json
            settings = {
                "block_duration": str(time_int),
                "block_threshold": str(threshold_int)
            }
            
            with open('ip_settings.json', 'w') as f:
                json.dump(settings, f, indent=2)
            
            # Start/restart monitoring with new settings
            ip_monitor.stop_monitoring()
            ip_monitor.start_monitoring()
            
            proxy_logger.info(f"📋 IP blacklist settings updated: duration={time_int}min, threshold={threshold_int}")
            proxy_logger.info("🔍 IP blacklist monitoring restarted with new settings")
            
            return jsonify({"success": True, "message": "Settings saved and monitoring started"})
        except ValueError:
            return jsonify({"error": "Invalid values provided"}), 400
        except Exception as e:
            proxy_logger.error(f"Error saving IP settings: {str(e)}")
            return jsonify({"error": "Failed to save settings"}), 500
    
    # GET request
    try:
        settings = ip_monitor.load_settings()
        if settings:
            return jsonify({
                "block_duration": settings["block_duration"],
                "block_threshold": settings["block_threshold"],
                "monitoring_active": ip_monitor.monitoring
            })
        else:
            return jsonify({
                "block_duration": 60,
                "block_threshold": 8,
                "monitoring_active": False
            })
    except Exception as e:
        proxy_logger.error(f"Error loading IP settings: {str(e)}")
        return jsonify({"error": "Failed to load settings"}), 500
    
# For testing the new feature - ip monitoring
# Add endpoint to manually trigger IP analysis (optional, for testing)
@app.route('/api/ip-analysis/trigger', methods=['POST'])
def trigger_ip_analysis():
    try:
        ip_monitor.process_ip_blocking()
        return jsonify({"success": True, "message": "IP analysis triggered"})
    except Exception as e:
        proxy_logger.error(f"Error triggering IP analysis: {str(e)}")
        return jsonify({"error": "Failed to trigger analysis"}), 500

# Add endpoint to get monitoring status
@app.route('/api/ip-analysis/status', methods=['GET'])
def get_ip_analysis_status():
    try:
        settings = ip_monitor.load_settings()
        return jsonify({
            "monitoring_active": ip_monitor.monitoring,
            "settings_configured": settings is not None,
            "settings": settings
        })
    except Exception as e:
        proxy_logger.error(f"Error getting IP analysis status: {str(e)}")
        return jsonify({"error": "Failed to get status"}), 500


#------------------------------------------ whois database-------------
@app.route("/api/whois-sync", methods=["POST"])
def whois_sync():
    import requests
    from pathlib import Path
# -----------------------Add URLs to sync with whois database -----------------------
    urls = {
        "apnic": "https://ftp.apnic.net/apnic/whois/apnic.db.inetnum.gz",
        "ripe": "https://ftp.ripe.net/ripe/dbase/ripe.db.gz"
    }

    output_dirs = {
        "apnic": Path("whois_db/apnic"),
        "ripe": Path("whois_db/ripe")
    }

    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; WHOIS Sync Script)"
    }

    try:
        for registry, url in urls.items():
            out_dir = output_dirs[registry]
            out_dir.mkdir(parents=True, exist_ok=True)
            filename = url.split("/")[-1]
            target_path = out_dir / filename
            resp = requests.get(url, headers=headers, timeout=60, stream=True)
            if resp.status_code == 200:
                with open(target_path, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:  # filter out keep-alive chunks
                            f.write(chunk)
            else:
                return jsonify({"error": f"Failed to download {registry} DB (status {resp.status_code})"}), 500

        return jsonify({"success": True, "message": "WHOIS databases synced."})

    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Connection failed: {str(e)}"}), 500




# ---------- ANALYTICS ------------------------------------------------------
@app.route('/api/analytics/filtered', methods=['GET'])
def get_filtered_analytics():
    time_range = request.args.get('time_range', '24h')
    filter_type = request.args.get('filter_type', 'all')
    
    logs = load_dns_logs()
    
    # Filter by time range
    now = datetime.now()
    if time_range == '1h':
        cutoff = now - timedelta(hours=1)
    elif time_range == '24h':
        cutoff = now - timedelta(days=1)
    elif time_range == '7d':
        cutoff = now - timedelta(days=7)
    elif time_range == '30d':
        cutoff = now - timedelta(days=30)
    else:
        cutoff = datetime.min  # All time
    
    filtered_logs = []
    for log in logs:
        try:
            if isinstance(log, dict):
                timestamp = datetime.fromisoformat(log['timestamp'])
            else:
                # Parse timestamp from log string
                parts = log.split(' ')
                timestamp = datetime.strptime(f"{parts[0]} {parts[1]}", "%Y-%m-%d %H:%M:%S,%f")
            
            if timestamp >= cutoff:
                filtered_logs.append(log)
        except Exception as e:
            print(f"Error processing log entry: {e}")
    
    # Filter by type
    if filter_type == 'blocked':
        filtered_logs = [log for log in filtered_logs if "verdict=BLOCK" in str(log)]
    elif filter_type == 'suspicious':
        filtered_logs = [log for log in filtered_logs if "verdict=SUSPICIOUS" in str(log)]
    elif filter_type == 'allowed':
        filtered_logs = [log for log in filtered_logs if "verdict=ALLOW" in str(log)]
    
    return jsonify(filtered_logs)

@app.route('/api/analytics/summary')
def get_analytics_summary():
    logs = load_dns_logs()
    
    unique_clients = 0
    blocked_count = 0
    suspicious_count = 0
    allowed_count = 0
    client_counts = {}
    domain_counts = {}
    domain_clients = {}
    suspicious_domain_counts = {}
    suspicious_domain_clients = {}

    for log in reversed(logs):  # reversed = most recent first
        try:
            if isinstance(log, dict):
                client = log.get('client_ip') or log.get('client') or 'unknown'
                verdict = log.get('verdict', 'UNKNOWN')
                domain = log.get('domain', '')
            else:
                client_match = re.search(r'client(?:_ip)?=([^\s|]+)', log)
                client = client_match.group(1) if client_match else 'unknown'
                
                verdict_match = re.search(r'verdict=(\w+)', log)
                verdict = verdict_match.group(1) if verdict_match else 'UNKNOWN'
                
                domain_match = re.search(r'domain=([^\s|]+)', log)
                domain = domain_match.group(1) if domain_match else ''

            if client != 'unknown':
                client_counts[client] = client_counts.get(client, 0) + 1

            if verdict == "BLOCK":
                blocked_count += 1
                if domain:
                    domain_counts[domain] = domain_counts.get(domain, 0) + 1
                    if domain not in domain_clients:
                        domain_clients[domain] = client
            elif verdict == "SUSPICIOUS":
                suspicious_count += 1
                if domain:
                    suspicious_domain_counts[domain] = suspicious_domain_counts.get(domain, 0) + 1
                    if domain not in suspicious_domain_clients:
                        suspicious_domain_clients[domain] = client
            else:
                allowed_count += 1 

        except Exception as e:
            print(f"Error processing log entry: {e}")
    
    unique_clients = len(client_counts)
    top_domains = sorted(domain_counts.items(), key=lambda x: x[1], reverse=True)[:5]

    top_blocked = []
    for domain, count in top_domains:
        client_ip = domain_clients.get(domain, "")
        top_blocked.append({
            "domain": domain,
            "count": count,
            "client_ip": client_ip
        })

    top_suspicious_domains = sorted(suspicious_domain_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    top_suspicious = []
    for domain, count in top_suspicious_domains:
        client_ip = suspicious_domain_clients.get(domain, "")
        top_suspicious.append({
            "domain": domain,
            "count": count,
            "client_ip": client_ip
        })

    return jsonify({
    'unique_clients': unique_clients,
    'blocked_count': blocked_count,
    'suspicious_count': suspicious_count,
    'allowed_count': allowed_count,
    'top_blocked_domains': top_blocked,
    'top_suspicious_domains': top_suspicious
})



# ---------- DNS-Rule CRUD ---------------------------------------------------
@app.route("/api/dns-rules", methods=["GET", "POST"])
def dns_rules():
    if request.method == "POST":
        rules = load_dns_rules()
        new   = request.json | {
            "id"     : (max([r['id'] for r in rules]) if rules else 0) + 1,
            "created": datetime.now().isoformat()
        }
        rules.append(new)
        save_dns_rules(rules)
        return jsonify(new), 201
    return jsonify(load_dns_rules())

@app.route("/api/dns-rules/<int:rule_id>", methods=["PUT", "DELETE"])
def dns_rule(rule_id):
    rules = load_dns_rules()
    rule  = next((r for r in rules if r["id"] == rule_id), None)
    if not rule:
        return jsonify({"error": "Rule not found"}), 404

    if request.method == "PUT":
        # Remove enabled field if present
        updated = request.json
        updated.pop("enabled", None)
        rule.update(updated)
        save_dns_rules(rules)
        return jsonify(rule)
    # DELETE
    rules = [r for r in rules if r["id"] != rule_id]
    save_dns_rules(rules)
    return jsonify({"success": True})


@app.route("/api/dns-rules/bulk", methods=["POST"])
def dns_rules_bulk():
    rules      = load_dns_rules()
    new_rules  = request.json.get("rules", [])
    next_id    = (max([r['id'] for r in rules]) if rules else 0) + 1
    for r in new_rules:
        r["id"]      = next_id
        r["created"] = datetime.now().isoformat()
        next_id     += 1
        rules.append(r)
    save_dns_rules(rules)
    return jsonify({"success": True, "added": len(new_rules), "total": len(rules)})

# NEW: File upload endpoint
@app.route("/api/upload-domain-rules", methods=["POST"])
def upload_domain_rules():
    file = request.files.get('file')
    action = request.form.get('action')
    
    if not file or not action:
        return jsonify({"error": "Missing file or action type"}), 400
    
    target_file = 'whitelist_domains.txt' if action == 'ALLOW' else 'blacklist_domains.txt'
    
    try:
        # Read existing domains
        existing_domains = set()
        if os.path.exists(target_file):
            with open(target_file, 'r') as f:
                existing_domains = set(line.strip() for line in f if line.strip())
        
        # Process uploaded file
        content = file.stream.read().decode('utf-8').splitlines()
        new_domains = set()
        
        for line in content:
            domain = line.strip()
            if not domain or domain.startswith('#'):
                continue
            domain = re.sub(r'\s+', '', domain)
            if domain and domain not in existing_domains:
                new_domains.add(domain)
        
        # Append new domains to target file
        added_to_file = 0
        if new_domains:
            with open(target_file, 'a') as f:
                for domain in new_domains:
                    f.write(f"{domain}\n")
                    added_to_file += 1
        
        # Load current rules
        rules = load_dns_rules()
        added_to_rules = 0
        updated_count = 0
        next_id = (max([r['id'] for r in rules]) + 1) if rules else 1
        
        # Process domains - update existing or add new
        for domain in new_domains:
            # Check if domain already exists in rules
            existing_rule = next((r for r in rules if r['domain'] == domain), None)
            
            if existing_rule:
                # Update existing rule with new action
                existing_rule['action'] = action
                updated_count += 1
            else:
                # Add new rule
                rules.append({
                    "id": next_id,
                    "domain": domain,
                    "action": action,
                    "created": datetime.now().isoformat()
                })
                next_id += 1
                added_to_rules += 1
        
        # Save updated rules
        if added_to_rules > 0 or updated_count > 0:
            save_dns_rules(rules)
        
        return jsonify({
            "success": True,
            "action": action,
            "file": target_file,
            "added_to_file": added_to_file,
            "added_to_rules": added_to_rules,
            "updated_rules": updated_count
        })
    
    except Exception as e:
        return jsonify({"error": f"Error processing file: {str(e)}"}), 500
    
# Add this debug endpoint to your Flask app
@app.route("/api/debug/chunk-inspect", methods=["GET"])
def debug_chunk_inspect():
    """Debug endpoint to inspect chunk contents"""
    try:
        # Get the latest chunk
        try:
            latest = max(CHUNK_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime)
        except ValueError:
            return jsonify({"error": "No chunk files found"}), 404

        # Read and analyze the chunk
        with open(latest, 'r') as f:
            rows = json.load(f)
        
        analysis = {
            "chunk_file": str(latest.name),
            "total_entries": len(rows),
            "sample_entries": rows[:3] if rows else [],
            "entry_types": {},
            "available_fields": set()
        }
        
        # Analyze entry structure
        for row in rows[:10]:  # Sample first 10 entries
            entry_type = type(row).__name__
            analysis["entry_types"][entry_type] = analysis["entry_types"].get(entry_type, 0) + 1
            
            if isinstance(row, dict):
                analysis["available_fields"].update(row.keys())
        
        analysis["available_fields"] = list(analysis["available_fields"])
        
        return jsonify(analysis)
        
    except Exception as e:
        return jsonify({"error": f"Debug error: {str(e)}"}), 500
    
# ---------------------------------------------------------------------------
#  DOMAIN-RULES  (Client-A + Client-B ⇢ two objects inside domain_rules.json)
# ---------------------------------------------------------------------------
@app.route("/api/domain-rules", methods=["POST"])
def add_domain_rule():
    """
    Updated to handle only Client A fields since Client B was removed from frontend.
    Expected JSON payload:
    {
      "domain"        : "example.com",
      "clientA_subnet": "192.168.0.0/24", 
      "clientA_ip"    : "192.168.0.5"
    }
    """
    payload = request.json or {}
    
    # Only require the fields that are actually sent from the frontend
    required = ["domain", "clientA_subnet", "clientA_ip"]
    missing = [k for k in required if not payload.get(k)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    domain = payload["domain"].strip().lower()

    # Load → mutate → save (append-only)
    doc = load_domain_rules()
    rules = doc["rules"]

    # Only add one rule object since we only have Client A data
    rules.append({
        "subnet": payload["clientA_subnet"],
        "domain": domain,
        "ip"    : payload["clientA_ip"]
    })
    
    save_domain_rules(doc)
    return jsonify({"success": True, "added": 1}), 201

# ---------- USER CRUD -------------------------------------------------------
@app.route("/api/users", methods=["GET", "POST"])
def users():
    if request.method == "POST":
        users = load_users()
        new_user = request.json
        new_user["password"] = generate_password_hash(new_user["password"])
        # Check if username already exists
        if any(u["username"] == new_user["username"] for u in users):
            return jsonify({"error": "Username already exists"}), 400
            
        new_user["id"] = (max([u["id"] for u in users]) if users else 0) + 1
        users.append(new_user)
        save_users(users)
        return jsonify(new_user), 201
    return jsonify(load_users())

@app.route("/api/users/<int:user_id>", methods=["PUT", "DELETE"])
def user(user_id):
    users = load_users()
    usr   = next((u for u in users if u["id"] == user_id), None)
    if not usr:
        return jsonify({"error": "User not found"}), 404

    if request.method == "PUT":
        incoming = request.json or {}
        # hash the password only if the admin actually sent one
        if "password" in incoming:
            incoming["password"] = generate_password_hash(incoming["password"])
        usr.update(incoming)
        save_users(users)
        return jsonify(usr)
    
    users = [u for u in users if u["id"] != user_id]
    save_users(users)
    return jsonify({"success": True})

# ===========================================================================
# 7) Entrypoint  (unchanged)
# ===========================================================================
if __name__ == "__main__":
    # Keeps main thread alive just like Script-1
    app.run(host="0.0.0.0", port=8000, debug=True)