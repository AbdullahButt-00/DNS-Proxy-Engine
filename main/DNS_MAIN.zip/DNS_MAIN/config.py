# config.py
from pathlib import Path
import json, os

THR_FILE = "thresholds.json"
DEFAULT_BLOCK = float(os.getenv("DNS_BLOCK_THR", 0.30))
DEFAULT_SUSP  = float(os.getenv("DNS_SUSP_THR", 0.50))

def load_thresholds():
    Path(THR_FILE).touch(exist_ok=True)
    try:
        with open(THR_FILE) as f:
            d = json.load(f)
            return float(d.get("block", DEFAULT_BLOCK)), float(d.get("suspicious", DEFAULT_SUSP))
    except (ValueError, json.JSONDecodeError):
        return DEFAULT_BLOCK, DEFAULT_SUSP

def save_thresholds(block, susp):
    with open(THR_FILE, "w") as f:
        json.dump({"block": block, "suspicious": susp}, f, indent=2)
