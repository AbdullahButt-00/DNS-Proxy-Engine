# scoring_engine.py

import math
import time
import random
from collections import defaultdict, deque
import socket, gzip, re, itertools, datetime as dt, pathlib

import logging

# ---------------------------------------------------------------------------
# Config toggles
# ---------------------------------------------------------------------------
USE_WHOIS_METHOD = True    # Enable WHOIS lookup using python-whois
USE_RIR_FALLBACK = True     # Enable fallback method using RIR file parsing

# ---------------------------------------------------------------------------
# Multi-RIR APNIC/ARIN/RIPE parser (first 20,000 ranges from each)
# ---------------------------------------------------------------------------
print("🔧 Domain Age Scoring Configuration:")
print(f"   WHOIS method enabled     : {USE_WHOIS_METHOD}")
print(f"   RIR fallback method used : {USE_RIR_FALLBACK}")

IP_RANGES: list[tuple[int, int, int, str]] = []  # (start_int, end_int, created_ts, source)

def _ip_to_int(ip: str) -> int:
    return sum(int(b) << (8 * (3 - i)) for i, b in enumerate(ip.split(".")))

def _load_rir_ranges():
    """Load IP ranges from multiple RIR databases"""
    rir_configs = [
        {
            "path": "whois_db/apnic/apnic.db.inetnum.gz",
            "name": "APNIC",
            "limit": 20000
        },
        {
            "path": "whois_db/arin/arin.db.inetnum.gz", 
            "name": "ARIN",
            "limit": 20000
        },
        {
            "path": "whois_db/ripe/ripe.db.inetnum.gz",
            "name": "RIPE", 
            "limit": 20000
        }
    ]
    
    total_loaded = 0
    
    for rir in rir_configs:
        if not pathlib.Path(rir["path"]).exists():
            print(f"⚠️  {rir['name']} data file not found at {rir['path']}")
            continue
            
        print(f"📥 Loading {rir['name']} IP ranges from: {rir['path']}")
        rec = {}
        ranges_loaded = 0
        
        try:
            with gzip.open(rir["path"], "rt", encoding="utf-8", errors="ignore") as fh:
                for line in fh:
                    if line.strip() == "":
                        if "inetnum" in rec and ("created" in rec or "changed" in rec or "last-modified" in rec):
                            # Handle different inetnum formats
                            inetnum = rec["inetnum"]
                            if " - " in inetnum:
                                # Format: "1.2.3.4 - 1.2.3.255"
                                ip1, ip2 = (s.strip() for s in inetnum.split(" - "))
                            elif "/" in inetnum:
                                # Format: "1.2.3.0/24" - convert CIDR to range
                                import ipaddress
                                try:
                                    network = ipaddress.IPv4Network(inetnum, strict=False)
                                    ip1 = str(network.network_address)
                                    ip2 = str(network.broadcast_address)
                                except:
                                    continue
                            else:
                                continue
                                
                            try:
                                start = _ip_to_int(ip1)
                                end = _ip_to_int(ip2)

                                # Get the best available date field
                                date_str = rec.get("created") or rec.get("changed") or rec.get("last-modified")

                                # Handle different formats
                                if "T" in date_str:
                                    # Format: YYYY-MM-DDTHH:MM:SSZ
                                    ts = int(dt.datetime.strptime(date_str[:10], "%Y-%m-%d").timestamp())
                                else:
                                    # Format: YYYYMMDD
                                    ts = int(dt.datetime.strptime(date_str[:8], "%Y%m%d").timestamp())

                                IP_RANGES.append((start, end, ts, rir["name"]))
                                ranges_loaded += 1

                                if ranges_loaded >= rir["limit"]:
                                    break
                            except Exception as e:
                                continue
                        rec = {}
                    elif line and line[0] not in "%#":
                        if ":" in line:
                            try:
                                k, v = map(str.strip, line.split(":", 1))
                                rec[k.lower()] = v
                            except ValueError:
                                continue
        except Exception as e:
            print(f"⚠️  Error loading {rir['name']}: {e}")
            continue
            
        print(f"✅ Loaded {ranges_loaded} IP ranges from {rir['name']}")
        total_loaded += ranges_loaded

    print(f"🌍 Total loaded: {total_loaded} IP ranges from {len([r for r in rir_configs if pathlib.Path(r['path']).exists()])} RIRs")

_load_rir_ranges()  # Load from multiple RIRs

_domain_age_cache: dict[str, float] = {}

def _get_domain_age_whois(domain: str) -> float | None:
    try:
        import whois
        w = whois.whois(domain)
        creation_date = w.creation_date

        if isinstance(creation_date, list):
            creation_date = creation_date[0]

        if creation_date:
            age_days = (time.time() - creation_date.timestamp()) / 86400
            # score = 1.0 if age_days >= 365 else random.uniform(0.4, 0.6)
            if age_days >= 365:
                score = random.uniform(0.75, 1.0)
            else:
                score = random.uniform(0.4, 0.6)
            print(f"🌐 [WHOIS] Domain: {domain} → Age: {round(age_days)} days → Score: {round(score, 2)}")
            return round(score, 2)
    except Exception as e:
        print(f"❌ WHOIS lookup failed for {domain}: {e}")
    return None

def calculate_domain_age_score(domain: str) -> float:
    domain = domain.lower().strip()

    if domain in _domain_age_cache:
        return _domain_age_cache[domain]

    score = None

    # 🌐 Try WHOIS method if enabled
    if USE_WHOIS_METHOD:
        score = _get_domain_age_whois(domain)

    # 🔁 If WHOIS failed or disabled, try RIR fallback
    if score is None and USE_RIR_FALLBACK:
        try:
            ip = socket.gethostbyname(domain)
            ip_int = _ip_to_int(ip)
            for start, end, ts, source in IP_RANGES:
                if start <= ip_int <= end:
                    age_days = (time.time() - ts) / 86400
                    # score = 1.0 if age_days >= 365 else random.uniform(0.4, 0.6)
                    if age_days >= 365:
                        score = random.uniform(0.75, 1.0)
                    else:
                        score = random.uniform(0.4, 0.6)
                    score = round(score, 2)
                    print(f"🌐 [FALLBACK] Domain: {domain} → IP: {ip} → {source} range age: {round(age_days)} days → Score: {score}")
                    break
        except Exception as e:
            print(f"❌ Failed to resolve domain or match IP: {domain} — {e}")

    # 🧩 Final fallback if no method succeeded
    if score is None:
        print(f"❓ Domain: {domain} → No match found → Score: 0.5")
        score = 0.55

    _domain_age_cache[domain] = score
    return score

# ---------------------------------------------------------------------------
# 2)  TLD score
# ---------------------------------------------------------------------------
LEGIT_TLDS = {'.com', '.org', '.net', '.edu', '.gov', '.mil'}
SUSPICIOUS_TLDS = {
    '.tk', '.ml', '.ga', '.cf', '.ru', '.su', '.xyz', '.top',
    '.work', '.click', '.download', '.stream', '.bid', '.science'
}

def calculate_tld_score(domain: str) -> float:
    tld = '.' + domain.rsplit('.', 1)[-1].lower()
    if tld in LEGIT_TLDS:      return 0.9
    if tld in SUSPICIOUS_TLDS: return 0.1
    return 0.6


# ---------------------------------------------------------------------------
# 3)  Frequency score (per-host sliding window, 60 s, 100 entries)
# ---------------------------------------------------------------------------
_query_history = defaultdict(lambda: deque(maxlen=100))

def calculate_frequency_score(domain: str, client_ip: str) -> float:
    key = f"{client_ip}:{domain}"
    now = time.time()
    _query_history[key].append(now)

    recent = [t for t in _query_history[key] if now - t < 60]     # last 60 s
    if   len(recent) > 20: return 0.1
    elif len(recent) > 10: return 0.3
    elif len(recent) >  5: return 0.6
    return 0.9


# ---------------------------------------------------------------------------
# 4)  Entropy score (simple DGA heuristic on first label)
# ---------------------------------------------------------------------------
def calculate_entropy_score(domain: str) -> float:
    sub = domain.split('.', 1)[0]
    if len(sub) < 4:
        return 0.8                        # very short labels are usually fine

    counts = defaultdict(int)
    for c in sub:
        if c.isalpha():
            counts[c.lower()] += 1

    if not counts:
        return 0.5                        # no letters → neutral

    tot  = sum(counts.values())
    ent  = -sum((cnt / tot) * math.log2(cnt / tot) for cnt in counts.values())
    norm = ent / 4.7                      # empirically ~4.7 bits = max entropy for letters

    if   norm > 0.95: return 0.1
    elif norm > 0.80: return 0.3
    elif norm > 0.60: return 0.6
    return 0.9


# ---------------------------------------------------------------------------
# 5)  Threat-feed presence (cached lists, loaded once)
# ---------------------------------------------------------------------------
_good: set[str] = set()
_bad:  set[str] = set()

def load_threat_caches(
    good_path: str = 'good_domains_cache.txt',
    bad_path:  str = 'malicious_domains_cache.txt'
) -> None:
    for path, target in ((good_path, _good), (bad_path, _bad)):
        try:
            with open(path, encoding='utf-8') as f:
                target.update(line.strip().lower() for line in f if line.strip())
        except FileNotFoundError:
            pass  # cache file missing → fine for now

def calculate_threat_intel_score(domain: str) -> float:
    d = domain.lower().lstrip('www.').strip('.')
    if d in _bad:   return 0.0
    if d in _good:  return 1.0
    return 0.5


# ---------------------------------------------------------------------------
# 6)  Reverse DNS (placeholder heuristic)
# ---------------------------------------------------------------------------
# def calculate_reverse_dns_score(domain: str) -> float:
#     return 0.7 if '.' in domain else 0.3
def calculate_reverse_dns_score(domain: str) -> float:
    try:
        # Resolve domain to IP
        ip = socket.gethostbyname(domain)
        
        # Perform reverse DNS lookup
        host, _, _ = socket.gethostbyaddr(ip)
        
        # Heuristic: if host contains domain, it's more trusted
        if domain in host:
            return 1.0  # Strong match
        else:
            return 0.7  # Reverse DNS exists, but hostname mismatch
    except socket.herror:
        # No PTR record
        print(f"🔍 No PTR record found for {domain}")
        return 0.3
    except Exception as e:
        # General failure (e.g. DNS resolution failure)
        print(f"⚠️ Reverse DNS check failed for {domain}: {e}")
        return 0.5  # Neutral score


# ---------------------------------------------------------------------------
# 7)  Simple network-behaviour score
# ---------------------------------------------------------------------------
_host_domain_hits = defaultdict(lambda: defaultdict(int))  # host → domain → count
_domain_seen_hosts = defaultdict(set)                      # domain → {hosts}
_domain_first_seen: dict[str, float] = {}                  # domain → timestamp
_all_hosts: set[str] = set()

def record_network_usage(domain: str, client_ip: str) -> None:
    now = time.time()
    _host_domain_hits[client_ip][domain] += 1
    _domain_seen_hosts[domain].add(client_ip)
    _all_hosts.add(client_ip)
    _domain_first_seen.setdefault(domain, now)

def calculate_network_score(domain: str, client_ip: str) -> float:
    """Combines host familiarity, domain popularity and age-in-network."""
    record_network_usage(domain, client_ip)

    # Host familiarity
    host_total   = sum(_host_domain_hits[client_ip].values())
    host_domain  = _host_domain_hits[client_ip][domain]
    familiarity  = min(1.0, host_domain / max(1, host_total * 0.1)) if host_total else 0.0

    # Domain popularity
    total_hosts  = len(_all_hosts)
    domain_hosts = len(_domain_seen_hosts[domain])
    popularity   = domain_hosts / total_hosts if total_hosts >= 3 else 0.5   # neutral early on

    # Domain first-seen age
    age_seconds  = time.time() - _domain_first_seen.get(domain, time.time())
    age_score    = min(1.0, age_seconds / 86_400)                            # full score ≥ 1 day

    # Aggregate (40 % + 40 % + 20 %)
    return (familiarity * 0.4) + (popularity * 0.4) + (age_score * 0.2)


# ---------------------------------------------------------------------------
# 8)  Combined reputation & verdict
# ---------------------------------------------------------------------------
def calculate_reputation(
    domain: str,
    client_ip: str,
    block_thr: float = 0.30,
    suspicious_thr: float = 0.50,
):
    """
    Returns
    -------
    final_score : float
    verdict     : str   ('ALLOW' | 'SUSPICIOUS' | 'BLOCK')
    detail      : dict  (all individual factor scores, incl. 'network')
    """

    # one-time cache load
    if not _good and not _bad:
        load_threat_caches()

    # individual factor scores
    t_scores = {
        'domain_age': calculate_domain_age_score(domain),
        'tld'       : calculate_tld_score(domain),
        'frequency' : calculate_frequency_score(domain, client_ip),
        'entropy'   : calculate_entropy_score(domain),
        'threat'    : calculate_threat_intel_score(domain),
        'reverse'   : calculate_reverse_dns_score(domain),
    }

    # Fast-path: malicious feed hit AND very young domain → immediate block
    if t_scores['threat'] == 0.0 and t_scores['domain_age'] < 0.3:
        t_scores['network'] = 0.0
        return 0.0, 'BLOCK', t_scores

    # Traditional weighted subtotal
    trad_weights = {
        'domain_age': 0.20,
        'tld'       : 0.15,
        'frequency' : 0.10,
        'entropy'   : 0.15,
        'threat'    : 0.25,
        'reverse'   : 0.05,
    }
    trad = sum(t_scores[f] * trad_weights[f] for f in trad_weights)

    # Network-behaviour component
    net = calculate_network_score(domain, client_ip)
    t_scores['network'] = net

    # Final score = 70 % traditional + 30 % network
    final = (trad * 0.7) + (net * 0.3)

    # Verdict
    if final <= block_thr:
        verdict = 'BLOCK'
    elif final <= suspicious_thr:
        verdict = 'SUSPICIOUS'
    else:
        verdict = 'ALLOW'

    return final, verdict, t_scores