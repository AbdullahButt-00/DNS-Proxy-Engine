# threat_feed_manager.py
from typing import Set
from urllib.parse import urlparse
import re, time, logging, urllib3, requests

# ── suppress InsecureRequestWarning ─────────────────────
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
# ────────────────────────────────────────────────────────

# ── NEW: global flag controlled by the Flask GUI ────────
NRD_ENABLED: bool = False  # default OFF


def set_nrd_enabled(v: bool) -> None:
    """Called by the Flask route to toggle 30-day-phishing harvesting."""
    global NRD_ENABLED
    NRD_ENABLED = bool(v)


# --------------------------------------------------------
class ThreatFeedManager:
    """Manages external threat intelligence feeds"""

    def __init__(self):
        self.malicious_domains: Set[str] = set()
        self.good_domains: Set[str] = set()
        self.last_update = 0
        self.update_interval = 3600  # seconds
        self.logger = logging.getLogger("ThreatFeeds")

        # Malicious feed URLs
        self.malicious_feeds = [
            "https://raw.githubusercontent.com/Phishing-Database/Phishing.Database/master/phishing-links-ACTIVE.txt",
            "https://raw.githubusercontent.com/Phishing-Database/Phishing.Database/master/phishing-domains-ACTIVE.txt",
            "https://urlhaus.abuse.ch/downloads/text_recent/",
            "https://urlhaus.abuse.ch/downloads/text_online/",
            "https://urlhaus.abuse.ch/downloads/text/",
            "https://urlhaus.abuse.ch/downloads/hostfile/",
            "https://urlhaus.abuse.ch/downloads/csv_recent/",
            "https://urlhaus.abuse.ch/downloads/csv_online/",
            "https://feodotracker.abuse.ch/downloads/ipblocklist_recommended.txt",
            "https://www.malwaredomainlist.com/hostslist/hosts.txt",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
            "https://someonewhocares.org/hosts/zero/hosts",
            "http://data.phishtank.com/data/online-valid.csv",
            "https://openphish.com/feed.txt",
            "https://raw.githubusercontent.com/mitchellkrogza/nginx-ultimate-bad-bot-blocker/master/_generator_lists/bad-referrers.list",
        ]

        # Legitimate feed URLs
        self.good_feeds = [
            "https://tranco-list.eu/download/daily/tranco_2NW29-1m.csv.zip",
            "http://s3-us-west-1.amazonaws.com/umbrella-static/top-1m.csv.zip",
            "https://raw.githubusercontent.com/mozilla/publicsuffix/master/public_suffix_list.dat",
        ]

        # Additional “pro” blocklist URL
        self.pro_feeds = [
            "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/domains/pro.txt",
            # "https://example.com/another_pro_list.txt",
        ]

        # NRD (30-day phishing) repo info
        self.nrd_sources = [
            {
                "tree_api":  "https://api.github.com/repos/xRuffKez/NRD/git/trees/main?recursive=1",
                "raw_base":  "https://raw.githubusercontent.com/xRuffKez/NRD/main/",
                "prefix":    "lists/30-day_phishing/",
            },
            {
                "tree_api":  "https://api.github.com/SomeOther/Repo/git/trees/main?recursive=1",
                "raw_base":  "https://raw.githubusercontent.com/SomeOther/Repo/main/",
                "prefix":    "/lists/14-day-mini/adblock/",
            }
        ]

    # --------------------------------------------------------------------- #
    # Feed-fetching / parsing
    # --------------------------------------------------------------------- #
    def update_feeds_sync(self):
        """Fetch & parse every feed, then overwrite cache files"""
        import requests, zipfile, io

        # avoid very frequent refreshes
        if time.time() - self.last_update < self.update_interval:
            return

        session = requests.Session()
        session.verify = False
        total_bad = total_good = 0

        # ── MALICIOUS FEEDS ───────────────────────────────────────────────
        for url in self.malicious_feeds:
            try:
                r = session.get(url, timeout=30)
                if r.status_code != 200:
                    continue

                before = len(self.malicious_domains)
                for line in r.text.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    # 0) Regex catch-all — grabs domain from hosts-file / URL style
                    match = re.search(
                        r"(?:(?:https?://)?(?:0\.0\.0\.0|127\.0\.0\.1)?\s*)"
                        r"([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})",
                        line,
                    )
                    if match:
                        self.malicious_domains.add(match.group(1).lower())
                        continue  # already handled

                    # 1) Explicit URL
                    if line.lower().startswith(("http://", "https://")):
                        host = urlparse(line).netloc.lower()
                        if host:
                            self.malicious_domains.add(host)
                        continue

                    # 2) Plain host string or hosts-file line
                    if "." in line and "," not in line:
                        parts = line.split()
                        # hosts-file format: "0.0.0.0 domain.com"
                        if len(parts) == 2 and parts[0] in ("0.0.0.0", "127.0.0.1"):
                            self.malicious_domains.add(parts[1].lower())
                        else:
                            self.malicious_domains.add(parts[0].lower())

                total_bad += len(self.malicious_domains) - before
            except Exception:
                continue

        # ── GOOD FEEDS ────────────────────────────────────────────────────
        for url in self.good_feeds:
            try:
                before = len(self.good_domains)
                if url.endswith(".zip"):
                    r = session.get(url, timeout=60)
                    z = zipfile.ZipFile(io.BytesIO(r.content))
                    content = z.open(z.namelist()[0]).read().decode(errors="ignore")
                    lines = content.splitlines()
                else:
                    r = session.get(url, timeout=30)
                    lines = r.text.splitlines()

                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("//"):
                        continue
                    if "," in line:  # CSV: rank,domain
                        domain = line.split(",", 1)[1].strip().strip('"').lower()
                    else:
                        domain = line.lower()
                    if "." in domain:
                        self.good_domains.add(domain)

                total_good += len(self.good_domains) - before
            except Exception:
                continue

        # Write out caches
        with open("malicious_domains_cache.txt", "w") as f:
            f.write("\n".join(sorted(self.malicious_domains)))
        with open("good_domains_cache.txt", "w") as f:
            f.write("\n".join(sorted(self.good_domains)))

        # ------------------------------------------------------------------
        # PRO lists → blacklist_domains.txt   (DISABLED as requested)
        # ------------------------------------------------------------------
        for url in self.pro_feeds:
            try:
                r = session.get(url, timeout=30)
                if r.status_code != 200:
                    continue
                lines = [
                    l.strip().lower()
                    for l in r.text.splitlines()
                    if l.strip() and not l.startswith("#")
                ]
                with open("blacklist_domains.txt", "a") as f:
                    f.write("\n".join(lines) + "\n")
                self.logger.info(
                    f"PRO blocklist fetched: {len(lines)} domains from {url}"
                )
            except Exception as e:
                self.logger.error(f"Failed PRO fetch {url}: {e}")


        # ------------------------------------------------------------------
        # NRD 30-day phishing (only when toggle enabled)
        # ------------------------------------------------------------------
        if NRD_ENABLED:
            self.logger.info("NRD enabled → fetching 30-day phishing TXT files")
            self._fetch_nrd_phishing()
        else:
            self.logger.debug("NRD disabled → skipping 30-day phishing lists")

        self.last_update = time.time()
        self.logger.info(f"Feeds updated: +{total_bad} bad, +{total_good} good")

    # --------------------------------------------------------------------- #
    # Helpers
    # --------------------------------------------------------------------- #
    _DOMAIN_RE = re.compile(
        r"^(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,}$"
    )

    def _fetch_nrd_phishing(self):
        """Fetch every .txt from every NRD source and append clean domains."""
        try:
            session = requests.Session()
            session.verify = False

            grand_total = 0

            for src in self.nrd_sources:
                # 1) enumerate files
                r = session.get(src["tree_api"], timeout=10)
                r.raise_for_status()
                tree = r.json().get("tree", [])
                txt_paths = [
                    e["path"]
                    for e in tree
                    if e["path"].startswith(src["prefix"]) and e["path"].endswith(".txt")
                ]

                new_domains = set()
                for path in txt_paths:
                    raw_url = src["raw_base"] + path
                    rr = session.get(raw_url, timeout=10)
                    if rr.status_code != 200:
                        continue

                    for line in rr.text.splitlines():
                        line = line.strip()
                        if not line or line.startswith(("!", "#", "//")) or line.lower().startswith("local-zone:"):
                            continue
                        clean = (
                            line[2:].rstrip("^") if line.startswith("||")
                            else line[2:]          if line.startswith("*.")
                            else line
                        ).lower()
                        if self._DOMAIN_RE.match(clean):
                            new_domains.add(clean)

                if new_domains:
                    self.malicious_domains.update(new_domains)
                    with open("blacklist_domains.txt", "a") as f:
                        for d in sorted(new_domains):
                            f.write(d + "\n")
                    self.logger.info(f"[NRD] {len(new_domains)} domains from {src['prefix']}")
                    grand_total += len(new_domains)

            if grand_total:
                self.logger.info(f"[NRD] fetched total {grand_total} phishing domains")

        except Exception as e:
            self.logger.error(f"[NRD] failed: {e}")

    # --------------------------------------------------------------------- #
    # Cache helpers
    # --------------------------------------------------------------------- #
    def load_cached(self):
        for path, bucket in (
            ("malicious_domains_cache.txt", self.malicious_domains),
            ("good_domains_cache.txt", self.good_domains),
        ):
            try:
                with open(path) as f:
                    bucket.update(line.strip() for line in f if line.strip())
            except FileNotFoundError:
                pass

    # --------------------------------------------------------------------- #
    # Query helpers
    # --------------------------------------------------------------------- #
    def is_malicious(self, domain: str) -> bool:
        return domain.lower() in self.malicious_domains

    def is_good(self, domain: str) -> bool:
        return domain.lower() in self.good_domains
