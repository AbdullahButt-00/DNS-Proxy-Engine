# ip_blacklist_monitor.py
import json
import os
import threading
import time
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path
import logging

class IPBlacklistMonitor:
    def __init__(self):
        self.logger = logging.getLogger("ip_blacklist_monitor")
        self.settings_file = "ip_settings.json"
        self.dns_logs_file = "dns_logs.json"
        self.blacklist_file = "blacklist_ips.txt"
        self.monitoring = False
        self.monitor_thread = None
        
        # Ensure blacklist file exists
        Path(self.blacklist_file).touch(exist_ok=True)
        
        # Start monitoring if settings exist
        self._start_monitoring_if_configured()
    
    def _start_monitoring_if_configured(self):
        """Start monitoring if ip_settings.json exists and is valid"""
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    settings = json.load(f)
                    if settings.get("block_duration") and settings.get("block_threshold"):
                        self.start_monitoring()
                        self.logger.info("🔍 IP Blacklist monitoring started automatically")
            except Exception as e:
                self.logger.error(f"Error reading settings file: {e}")
    
    def load_settings(self):
        """Load IP blacklist settings from file"""
        try:
            with open(self.settings_file, 'r') as f:
                settings = json.load(f)
                return {
                    "block_duration": int(settings.get("block_duration", 60)),
                    "block_threshold": int(settings.get("block_threshold", 8))
                }
        except (FileNotFoundError, json.JSONDecodeError, ValueError):
            return None
    
    def load_dns_logs(self):
        """Load DNS logs from file"""
        try:
            with open(self.dns_logs_file, 'r') as f:
                logs = json.load(f)
                return logs if isinstance(logs, list) else []
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    def filter_logs_by_timeframe(self, logs, minutes):
        """Filter logs to only include entries within the specified timeframe"""
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        filtered_logs = []
        
        for log in logs:
            try:
                if isinstance(log, dict):
                    timestamp_str = log.get("timestamp", "")
                else:
                    # Handle string format logs
                    import re
                    timestamp_match = re.search(r'timestamp=([^|]+)', str(log))
                    timestamp_str = timestamp_match.group(1).strip() if timestamp_match else ""
                
                if timestamp_str:
                    # Parse timestamp - handle different formats
                    try:
                        if ',' in timestamp_str:
                            # Format: "2025-07-29 21:21:42,123456"
                            timestamp = datetime.strptime(timestamp_str.split(',')[0], "%Y-%m-%d %H:%M:%S")
                        else:
                            # Format: "2025-07-29 21:21:42"
                            timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
                        
                        if timestamp >= cutoff_time:
                            filtered_logs.append(log)
                    except ValueError as e:
                        self.logger.debug(f"Could not parse timestamp {timestamp_str}: {e}")
                        continue
            except Exception as e:
                self.logger.debug(f"Error processing log entry: {e}")
                continue
        
        return filtered_logs
    
    def group_logs_by_ip(self, logs):
        """Group logs by unique client IP addresses"""
        ip_groups = defaultdict(list)
        
        for log in logs:
            try:
                if isinstance(log, dict):
                    client_ip = log.get("client_ip") or log.get("client", "unknown")
                    verdict = log.get("verdict", "UNKNOWN")
                else:
                    # Handle string format logs
                    import re
                    client_match = re.search(r'client(?:_ip)?=([^|]+)', str(log))
                    client_ip = client_match.group(1).strip() if client_match else "unknown"
                    
                    verdict_match = re.search(r'verdict=([^|]+)', str(log))
                    verdict = verdict_match.group(1).strip() if verdict_match else "UNKNOWN"
                
                if client_ip != "unknown":
                    ip_groups[client_ip].append({
                        "log": log,
                        "verdict": verdict,
                        "client_ip": client_ip
                    })
            except Exception as e:
                self.logger.debug(f"Error processing log for IP grouping: {e}")
                continue
        
        return ip_groups
    
    def check_block_conditions(self, ip_groups, block_threshold):
        """Return list of IPs that have hit the BLOCK threshold."""
        ips_to_block = []

        for client_ip, logs in ip_groups.items():
            block_count    = sum(1 for entry in logs if entry["verdict"] == "BLOCK")
            total_requests = len(logs)

            self.logger.debug(
                f"IP {client_ip}: {block_count} blocks out of {total_requests} requests"
            )

            # Block once the number of BLOCK verdicts reaches (or exceeds) the threshold
            if block_count >= block_threshold:
                ips_to_block.append(client_ip)
                self.logger.info(
                    f"🚫 IP {client_ip} scheduled for blocking: "
                    f"{block_count} ≥ {block_threshold} BLOCKs "
                    f"({block_count}/{total_requests} requests)"
                )

        return ips_to_block

    
    def is_ip_already_blocked(self, ip):
        """Check if IP is already in blacklist"""
        try:
            with open(self.blacklist_file, 'r') as f:
                for line in f:
                    if line.strip().startswith(ip + "|") or line.strip() == ip:
                        return True
        except FileNotFoundError:
            pass
        return False
    
    def block_ip(self, ip):
        """Add IP to blacklist file"""
        if self.is_ip_already_blocked(ip):
            self.logger.info(f"IP {ip} is already blocked")
            return False
        
        try:
            with open(self.blacklist_file, 'a') as f:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"{ip}|{timestamp}\n")
            
            self.logger.warning(f"🚫 IP {ip} added to blacklist")
            return True
        except Exception as e:
            self.logger.error(f"Error adding IP {ip} to blacklist: {e}")
            return False
    
    def process_ip_blocking(self):
        """Main processing function to check and block IPs"""
        settings = self.load_settings()
        if not settings:
            self.logger.debug("No valid settings found, skipping IP blocking check")
            return
        
        block_duration = settings["block_duration"]
        block_threshold = settings["block_threshold"]
        
        self.logger.debug(f"Processing IP blocking with duration={block_duration}min, threshold={block_threshold}")
        
        # Load and filter logs
        all_logs = self.load_dns_logs()
        if not all_logs:
            self.logger.debug("No DNS logs found")
            return
        
        # Filter logs by timeframe
        recent_logs = self.filter_logs_by_timeframe(all_logs, block_duration)
        if not recent_logs:
            self.logger.debug(f"No logs found within last {block_duration} minutes")
            return
        
        self.logger.debug(f"Found {len(recent_logs)} logs within last {block_duration} minutes")
        
        # Group logs by IP
        ip_groups = self.group_logs_by_ip(recent_logs)
        if not ip_groups:
            self.logger.debug("No IP groups found")
            return
        
        self.logger.debug(f"Found {len(ip_groups)} unique IPs in recent logs")
        
        # Check blocking conditions
        ips_to_block = self.check_block_conditions(ip_groups, block_threshold)
        
        # Block IPs
        newly_blocked = 0
        for ip in ips_to_block:
            if self.block_ip(ip):
                newly_blocked += 1
        
        if newly_blocked > 0:
            self.logger.warning(f"🚫 Blocked {newly_blocked} new IP(s) based on threshold analysis")
        else:
            self.logger.debug("No new IPs blocked")
    
    def monitoring_loop(self):
        """Main monitoring loop"""
        self.logger.info("🔍 IP Blacklist monitoring loop started")
        
        while self.monitoring:
            try:
                self.process_ip_blocking()
                time.sleep(30)  # Check every 30 seconds
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Wait longer on error
    
    def start_monitoring(self):
        """Start the monitoring thread"""
        if self.monitoring:
            self.logger.info("IP monitoring is already running")
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self.monitoring_loop, daemon=True)
        self.monitor_thread.start()
        self.logger.info("🟢 IP Blacklist monitoring started")
    
    def stop_monitoring(self):
        """Stop the monitoring thread"""
        if not self.monitoring:
            return
        
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        self.logger.info("🔴 IP Blacklist monitoring stopped")

# Global instance
ip_monitor = IPBlacklistMonitor()