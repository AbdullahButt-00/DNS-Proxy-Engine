#!/usr/bin/env python3
"""
DNS Client Helper - Supporting dynamic IP specification
Usage examples:
  python dns_client_helper.py example.com --client-ip 192.168.1.100
  python dns_client_helper.py google.com --client-ip 10.0.0.5 --server 127.0.0.1 --port 5300
"""

import subprocess
import sys
import argparse
import socket
from dnslib import DNSRecord, QTYPE, RR, TXT

def create_dns_query_with_client_ip(domain, client_ip):
    """
    Create a DNS query with embedded client IP information.
    Method 1: Encode IP in domain name (most compatible with dig)
    """
    # Convert IP to domain-safe format: 192.168.1.100 -> 192-168-1-100
    ip_encoded = client_ip.replace('.', '-')
    modified_domain = f"{domain}.client-{ip_encoded}"
    return modified_domain

def send_raw_dns_query(domain, client_ip, server="127.0.0.1", port=5300):
    """
    Send a raw DNS query with TXT record containing client IP.
    Method 2: Use TXT record in additional section
    """
    try:
        # Create DNS query
        query = DNSRecord.question(domain, QTYPE.A)
        
        # Add TXT record with client IP in additional section
        txt_record = RR(
            rname="client-info",
            rtype=QTYPE.TXT,
            rdata=TXT(f"CLIENT_IP={client_ip}"),
            ttl=0
        )
        query.add_ar(txt_record)
        
        # Send query
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(5)
        sock.sendto(query.pack(), (server, port))
        
        # Receive response
        response_data, _ = sock.recvfrom(512)
        response = DNSRecord.parse(response_data)
        
        print(f"✅ Query sent for {domain} with client IP {client_ip}")
        print(f"📡 Response: {response}")
        
        for answer in response.rr:
            print(f"🎯 Answer: {answer}")
            
        sock.close()
        return True
        
    except Exception as e:
        print(f"❌ Error sending raw DNS query: {e}")
        return False

def send_dig_query_with_encoded_ip(domain, client_ip, server="127.0.0.1", port=5300):
    """
    Use standard dig with encoded domain name.
    Method 1: Most compatible approach
    """
    encoded_domain = create_dns_query_with_client_ip(domain, client_ip)
    
    cmd = [
        "dig", 
        f"@{server}", 
        "-p", str(port),
        encoded_domain,
        "+short"
    ]
    
    try:
        print(f"🚀 Executing: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            print(f"✅ Query successful for {domain} with client IP {client_ip}")
            if result.stdout.strip():
                print(f"📍 Response: {result.stdout.strip()}")
            else:
                print("📍 No response data (query may have been blocked)")
        else:
            print(f"❌ Query failed: {result.stderr}")
            
        return result.returncode == 0
        
    except subprocess.TimeoutExpired:
        print("⏰ Query timed out")
        return False
    except FileNotFoundError:
        print("❌ 'dig' command not found. Please install bind-utils or dnsutils package.")
        return False
    except Exception as e:
        print(f"❌ Error executing dig: {e}")
        return False

def validate_ip(ip):
    """Validate IP address format"""
    try:
        socket.inet_aton(ip)
        return True
    except socket.error:
        return False

def main():
    parser = argparse.ArgumentParser(
        description="DNS Client Helper with dynamic IP specification support",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s example.com --client-ip 192.168.1.100
  %(prog)s google.com --client-ip 10.0.0.5 --server 127.0.0.1 --port 5300
  %(prog)s malicious-site.com --client-ip 172.16.0.10 --method raw
        """
    )
    
    parser.add_argument("domain", help="Domain name to query")
    parser.add_argument("--client-ip", required=True, help="Client IP to simulate")
    parser.add_argument("--server", default="127.0.0.1", help="DNS server address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=5300, help="DNS server port (default: 5300)")
    parser.add_argument("--method", choices=["dig", "raw"], default="dig", 
                       help="Query method: 'dig' uses encoded domain, 'raw' uses TXT record")
    
    args = parser.parse_args()
    
    # Validate inputs
    if not validate_ip(args.client_ip):
        print(f"❌ Invalid client IP address: {args.client_ip}")
        sys.exit(1)
    
    if not validate_ip(args.server):
        print(f"❌ Invalid server IP address: {args.server}")
        sys.exit(1)
    
    print(f"🎯 Querying {args.domain} as client {args.client_ip}")
    print(f"📡 Target server: {args.server}:{args.port}")
    print(f"🔧 Method: {args.method}")
    print("-" * 50)
    
    # Execute query based on selected method
    if args.method == "dig":
        success = send_dig_query_with_encoded_ip(args.domain, args.client_ip, args.server, args.port)
    else:  # raw
        success = send_raw_dns_query(args.domain, args.client_ip, args.server, args.port)
    
    if success:
        print("\n✅ Query completed successfully")
        print(f"💡 Check your DNS proxy logs to verify client IP {args.client_ip} was used")
    else:
        print("\n❌ Query failed")
        sys.exit(1)

if __name__ == "__main__":
    main()